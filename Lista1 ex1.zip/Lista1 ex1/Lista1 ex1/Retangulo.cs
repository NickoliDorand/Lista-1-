﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1_ex1
{
    internal class Retangulo
    {
        private int base1;
        private int altura;
        private int resultado;

        public void setbase1(int n)
        {
            base1 = n;
        }
        public void setaltura(int n)
        {
            altura = n;
        }
        public int getbase1()
        {
            return base1;
        }
        public int getaltura()
        {
            return altura;
        }
        public int getResultado()
        {
            return resultado;
        }
        public void somar()
        {
            resultado = base1*altura;
        }
}
}
