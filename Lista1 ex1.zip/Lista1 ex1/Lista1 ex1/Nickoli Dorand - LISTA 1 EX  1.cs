﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1_ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Retangulo soma1;
            soma1 = new Retangulo();

            Console.Write("Digite a base do retângulo: ");
            soma1.setbase1(int.Parse(Console.ReadLine()));

            Console.Write("Digite a altura do retângulo: ");
            soma1.setaltura(int.Parse(Console.ReadLine()));

            soma1.somar();

            Console.WriteLine("A área do retângulo é: {0}", soma1.getResultado());


        }
    }
}
